<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</head>
	<body onLoad="window.print()">
	<!-- <body> -->
		<div style="width:1000px !important;padding:10px;" class="body">
			<!-- <table border="0" style="width:100%" cellpadding="0" cellspacing="0">
				<tr>
					<td style="width:15%;text-align:center;vertical-align:top">

					</td>
					<td style="width:70%;vertical-align:top;text-align:left">
						<h1 style="font-size:20px !important;">SEKOLAH ALAM BOGOR</h1>
						<h3>Alamat</h3>
					</td>
					<td style="width:15%;vertical-align:top;text-align:center;padding:4px;border :1px solid #ccc;">BUKTI PEMBAYARAN</td>
				</tr>
			</table>
			<hr> -->
      <table width="600" align="center" border="0" cellspacing="0" cellpadding="0" class="m_8333006706591979715borderPerTab" style="border:1px solid #ededed">
        <tbody><tr>

          <td bgcolor="#ffffff">

<table width="100%" align="center" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">

    <tbody><tr>
      <td valign="top" class="m_8333006706591979715vspacer15" width="45"></td>
      <td valign="top" style="font-family:Helvetica,'Arial',sans-serif;color:#000000;font-size:11px">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
           <tbody><tr>
            <td height="15"><img style="display:block" src="" alt="" width="20" height="15" border="0" class="CToWUd"></td>
          </tr>
           <tr>
            <td align="left" style="font-family:Helvetica,'Arial',sans-serif;color:#00af41;font-size:20px;line-height:24px;font-weight:bold;line-height:26px;text-align:left">
              Sekolah Alam Bogor
            </td>
          </tr>

           <tr>
            <td height="15"><img style="display:block" src="" alt="" width="20" height="15" border="0" class="CToWUd"></td>
          </tr>

            <tr>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tbody>
                      <tr>
                      <td width="56%" align="left" valign="top" class="m_8333006706591979715produceTdLast" style="font-size:12px;line-height:21px;font-weight:bold">TANGGAL &nbsp;&nbsp;<br>
                        <span style="font-size:12px;font-weight:bold;color:#00af41"><?=tgl_indo('2017-09-12')?></span></td>
                        <td width="44%" align="left" valign="top" class="m_8333006706591979715produceTdLast" style="font-size:12px;line-height:21px;font-weight:bold">&nbsp;</td>
                    </tr>
                  </tbody></table>

                  <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tbody><tr>
                      <td height="12"><img style="display:block" src="" alt="" width="20" height="12" border="0" class="CToWUd"></td>
                    </tr>
                  </tbody></table></td>
             </tr>

 </tbody></table></td>
           <td valign="top" class="m_8333006706591979715vspacer15" width="45"></td>
     </tr>
</tbody></table>




<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tbody><tr>
    <td height="5"><img style="display:block" src="" alt="" width="10" height="5" border="0" class="CToWUd"></td>
  </tr>
</tbody></table>


<table width="100%" align="center" border="0" cellspacing="0" cellpadding="0" bgcolor="#f4f4f4">
              <tbody><tr>
                <td valign="top" class="m_8333006706591979715vspacer15" width="45"><img style="display:block" src="" alt="" width="20" height="10" border="0" class="CToWUd"></td>

                <td align="center" valign="top">

                <table border="0" cellspacing="0" cellpadding="0" width="100%">
                    <tbody><tr>
                      <td align="left" height="20"></td>
                    </tr>
                  </tbody></table>

    <table border="0" cellspacing="0" cellpadding="0" width="100%">
                    <tbody><tr>

                      <td width="55%" align="left" style="font-size:14px;font-weight:bold;color:#00af41">

                      </td>
                    </tr>
                  </tbody></table>

                <table width="100%" border="0" cellspacing="0" cellpadding="0">
<tbody><tr>
<td valign="top" width="200" class="m_8333006706591979715produceTd">
 <table width="100%" border="0" cellspacing="0" cellpadding="0">
 	  <tbody><tr>
		<td align="left" valign="top" class="m_8333006706591979715tdp5" style="font-size:14px;font-weight:bold;color:#00af41">Data Siswa</td>
		</tr>


  <tr>
    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr>
          <td align="left" valign="top" style="padding:0cm 0cm 0cm 0cm">

        <table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tbody><tr>
                <td class="m_8333006706591979715t3_1" valign="top">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">

       <tbody><tr>
              <td align="left" valign="top" class="m_8333006706591979715tdp5">
                  <table border="0" cellspacing="0" cellpadding="0" width="100%">
                    <tbody><tr>
                      <td align="left" class="m_8333006706591979715tdp5">
                        <span style="font-size:10px;color:#9e9e9e;line-height:13px">Nama Siswa :</span><br>
                        <span style="font-size:12px;line-height:13px;font-weight:bold">Aisyah Humairah</span>
                      </td>
                    </tr>
                  </tbody></table>
              </td>
            </tr>

      <tr>
          <td align="left" valign="top" class="m_8333006706591979715tdp5">
            <table border="0" cellspacing="0" cellpadding="0" width="100%">
              <tbody><tr>
                 <td align="left" class="m_8333006706591979715tdp5">
                 <span style="font-size:10px;color:#9e9e9e;line-height:14px">Kelas : </span><br>
                 <span style="font-size:12px;line-height:13px;font-weight:bold">TKA-1 An-Nahl</span>
              </td>
              </tr>
            </tbody></table></td>
        </tr>


          </tbody>
        </table>
            </td>
              </tr>
            </tbody></table></td>
        </tr>
    </tbody></table></td>
  </tr>
  </tbody></table>
	</td>
    <td valign="top" class="m_8333006706591979715noneMobile" width="9"><img style="display:block" src="" alt="" width="9" height="10" border="0" class="CToWUd"></td>
    <td valign="top" class="m_8333006706591979715noneMobile" width="10" bgcolor="#f5f5f3"><img style="display:block" src="" alt="" width="10" height="10" border="0" class="CToWUd"></td>
    <td valign="top" width="270" class="m_8333006706591979715produceTd">
 <table width="100%" border="0" cellspacing="0" cellpadding="0">
 	<tbody><tr>
		<td align="left" valign="top" class="m_8333006706591979715tdp5" style="font-size:14px;font-weight:bold;color:#00af41">Detail Tagihan</td>
		</tr>
 	  <tr>
		<td align="center" valign="middle" height="10" class="m_8333006706591979715img_1"><img style="display:block" src="" alt="" width="170" height="10" border="0" class="CToWUd"></td>
		</tr>

  <tr>
    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff" style="border:1px solid #dddddd">
        <tbody><tr>
          <td align="left" valign="top" style="padding:0cm 0cm 0cm 0cm">

        <table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tbody><tr>
                <td class="m_8333006706591979715t3_1" valign="top">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">

        <tbody><tr>
              <td align="left" valign="top" class="m_8333006706591979715tdp5">
                  <table border="0" cellspacing="0" cellpadding="0" width="100%">
                  <tbody>
                  <tr>
                      <td align="left" class="m_8333006706591979715tdp5" width="15"></td>
                      <td width="171" align="left" class="m_8333006706591979715tdp5">
                      <span style="font-size:11px;color:#9e9e9e;line-height:21px">Jenis Tagihan</span>
                      </td>
                      <td width="80" align="left" class="m_8333006706591979715tdp5">
                      <span style="font-size:11px;color:#9e9e9e;line-height:28px">&nbsp;&nbsp;Jumlah:</span>
                      </td>
                      <td align="left" class="m_8333006706591979715tdp5" width="15"></td>
                    </tr>

                    <tr>
                      <td align="left" class="m_8333006706591979715tdp5" width="15"></td>
                      <td align="left" class="m_8333006706591979715tdp5">

                        <span style="font-size:11px;color:#000000;line-height:13px">SPP September 2017</span>

                      </td>
                      <td align="right" class="m_8333006706591979715tdp5">
                      <span style="font-size:11px;color:#000000;line-height:13px">&nbsp;&nbsp;Rp 650.000 </span>
                      </td>
                    </tr>
                    <tr>
                      <td align="left" class="m_8333006706591979715tdp5" width="15"></td>
                      <td align="left" class="m_8333006706591979715tdp5">
                      <span style="font-size:11px;color:#000000;line-height:13px">Catering September 2017</span>
                      </td>
                      <td align="right" class="m_8333006706591979715tdp5">
                      <span style="font-size:11px;color:#000000;line-height:13px">Rp 182.000 </span>
                      </td>
                    </tr>
                    <tr>
                      <td align="left" class="m_8333006706591979715tdp5" width="15"></td>
                      <td align="left" class="m_8333006706591979715tdp5">
                      <span style="font-size:11px;color:#000000;line-height:13px">Jemputan September 2017</span>
                      </td>
                      <td align="right" class="m_8333006706591979715tdp5">
                      <span style="font-size:11px;color:#000000;line-height:13px">Rp 182.000 </span>
                      </td>
                    </tr>
                    <tr>
                      <td align="left" class="m_8333006706591979715tdp5" width="15"></td>
                      <td align="left" class="m_8333006706591979715tdp5">
                      <span style="font-size:11px;color:#000000;line-height:13px">Investasi Tahun 2017</span>
                      </td>
                      <td align="right" class="m_8333006706591979715tdp5">
                      <span style="font-size:11px;color:#000000;line-height:13px">Rp 1.082.000 </span>
                      </td>
                    </tr>

                    <tr>
                      <td align="left" class="m_8333006706591979715tdp5" width="15"></td>
                      <td align="right" class="m_8333006706591979715tdp5">
                      <span style="font-size:12px;font-weight:bolder;color:#000000;line-height:18px">TOTAL&nbsp;&nbsp;&nbsp;&nbsp;</span>
                      </td>
                      <td align="right" class="m_8333006706591979715tdp5">
                      <span style="font-size:12px;font-weight:bolder;color:#000000;line-height:18px">&nbsp;&nbsp;RP 1.111.000</span>
                      </td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                    </tr>

                  </tbody></table>
              </td>
            </tr>




  </tbody></table>
            </td>
              </tr>
            </tbody></table></td>
        </tr>
    </tbody></table></td>
  </tr>
  </tbody></table>
	</td>

  </tr>
</tbody></table>

 <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tbody><tr>
          <td height="20"></td>
        </tr>
      </tbody></table>

        </td>
                <td valign="top" class="m_8333006706591979715vspacer15" width="45"><img style="display:block" src="" alt="" width="20" height="10" border="0" class="CToWUd"></td>
              </tr> </tbody></table>





<table width="100%" align="center" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
    <tbody><tr>
      <td valign="top" class="m_8333006706591979715vspacer15" width="45"></td>
      <td valign="top" style="font-family:'Helvetica',Arial,sans-serif;color:#000000;font-size:11px">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tbody><tr>
            <td align="left" style="font-family:'Helvetica',Arial,sans-serif;text-align:center">

            </td>
           </tr>

           <tr>
            <td align="left" style="font-family:'Helvetica',Arial,sans-serif;text-align:center">
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tbody><tr>
                      <td width="55%" align="left" valign="top" class="m_8333006706591979715produceTdLast" style="font-family:'Helvetica',Arial,sans-serif;color:#666666;padding-right:10%">
                      <span style="color:#666666"> <a href="mailto:admin@sekolahalambogor.id" style="font-size:10px;line-height:12px;font-weight:bold;color:#666666" target="_blank">admin@sekolahalambogor.id </a> &nbsp;&nbsp;|&nbsp;&nbsp;<a href="#" style="font-size:10px;font-weight:bold;color:#666666"> +62251 88877788</a></span><br><br>
            <span style="font-size:10px;font-weight:normal;line-height:13px">Copyright © 2017 Sekolah Alam Bogor
            </span>
                     </td>
                      <td width="35%" align="left" valign="top" class="m_8333006706591979715produceTdLast" style="font-family:'Helvetica',Arial,sans-serif;color:#666666">
                         <span style="font-size:10px;line-height:12px;font-weight:bold">Ketahui Info terbaru dari Sekolah Alam Bogor</span><br><br>
                          <a href="https://www.facebook.com/grab" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=id&amp;q=https://www.facebook.com/grab&amp;source=gmail&amp;ust=1505736257085000&amp;usg=AFQjCNHdZCG3Oj6zhPdi8YY7XyXW8VrKDQ"><img width="30px" src="https://ci3.googleusercontent.com/proxy/AA40_v0ZE3EVtW_zNL1uVY17uO67QIBE9wM--ZyJ_hPodC2-KsORjQWVy21Yu5bECt8qADqNOwGHb_G2did_jOHbUQb6kpc0jMGRbL77n6gHy4xdzi7h=s0-d-e1-ft#https://grabtaxi-marketing.s3.amazonaws.com/email/img/icon-fb.png" class="CToWUd"></a>&nbsp;&nbsp;
                          <a href="https://twitter.com/GrabID" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=id&amp;q=https://twitter.com/GrabID&amp;source=gmail&amp;ust=1505736257085000&amp;usg=AFQjCNHYFFd2PG127pmBWEe-Ic_WAV9zaA"><img width="30px" src="https://ci5.googleusercontent.com/proxy/W5MRG8dwdj793Fudb-YjlyW1QMrJaJew1r7Kla5ibvlYhsNMr6HW2RbXJ3no8Q1j-9tcYvBVLn0P-xiAZpI6xD5pjJM2fnpUaYJfj7uVFd7RxSnhIjzqcwCnG9I=s0-d-e1-ft#https://grabtaxi-marketing.s3.amazonaws.com/email/img/icon-twitter.png" class="CToWUd"></a>&nbsp;&nbsp;
                          <a href="https://instagram.com/GrabID" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=id&amp;q=https://instagram.com/GrabID&amp;source=gmail&amp;ust=1505736257085000&amp;usg=AFQjCNGKLhn84ufjmtRCC_Hh1FUqg_Czag"><img width="30px" src="https://ci5.googleusercontent.com/proxy/64yDxyUpghZN8W1rLWrRzch8PYi4np37qZi1yIPmAD7XCqAFne9YH6YwSj9A_uWggvSQ5D7992Np8vsaP-CsW1zo-ZBhOgcKKtoQZ9GV2D_3dtPg-0i--q5v88v9zQ=s0-d-e1-ft#https://grabtaxi-marketing.s3.amazonaws.com/email/img/icon-instagram.png" class="CToWUd"></a>&nbsp;&nbsp;

                          <a href="https://www.youtube.com/channel/UCGW3n9AJpF31TS9hqC7FXdw" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=id&amp;q=https://www.youtube.com/channel/UCGW3n9AJpF31TS9hqC7FXdw&amp;source=gmail&amp;ust=1505736257085000&amp;usg=AFQjCNGExHlBb9dFl0WB2_vCXdO4bpjylA"><img width="30px" src="https://ci4.googleusercontent.com/proxy/EaG6efvLuYghXtWhvaQSA6uA3wwizQam0WkBCsFN7b4rTsnhzFbfRtP3SHyxeEY6bnAJYh2We1wV7oOMj2pMB0ZFPMhyUySqIRholjRXaGwgfXeV6xC6wZkGpcg=s0-d-e1-ft#https://grabtaxi-marketing.s3.amazonaws.com/email/img/icon-youtube.png" class="CToWUd"></a>
                          <br><br>
                      </td>
                    </tr>
                  </tbody></table>
            </td>
           </tr>
           <tr>
            <td height="30"></td>
           </tr>


 </tbody></table></td>
           <td valign="top" class="m_8333006706591979715vspacer15" width="45"></td>
     </tr>
</tbody></table>

</td>
 </tr>
</tbody></table>


		</div>
	</body>
</html>
<style type="text/css" media="print">
  @page {
  	size: A4;
  }
  @media print {
  html, body {
    width: 210mm;
    height: 150mm;
  }
  /* ... the rest of the rules ... */
}
</style>
<style type="text/css">
*
{
	line-height: 20px;
	font-size : 105%;
}
.tabel th,
.tabel td
{

	vertical-align: top;
	padding:1px;
}
.tabel th
{
	background: #ddd;
	vertical-align: middle !important;
}

h1,h2,h3,h4,h5,h6
{
	padding: 1px !important;
	margin: 1px !important;
}
div
{
	font-size: 12px !important;
	padding-top:0px;
	padding-bottom:0px;
	margin-top:-1px !important;
	margin-bottom:0px;
}
ol li
{
	margin-top:3px !important;
	margin-bottom:0px !important;
}
div.b128{
	border-left: 1px black solid;
	height: 40px !important;
}

</style>
